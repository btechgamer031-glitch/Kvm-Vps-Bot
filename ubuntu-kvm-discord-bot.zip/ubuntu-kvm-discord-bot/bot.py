import os, sqlite3, secrets, string, subprocess, asyncio, re
from pathlib import Path
import discord
from discord import app_commands
from discord.ext import commands
from dotenv import load_dotenv
load_dotenv()

TOKEN=os.getenv('DISCORD_TOKEN','').strip()
ADMIN_IDS={int(x.strip()) for x in os.getenv('ADMIN_IDS','').split(',') if x.strip().isdigit()}
GUILD_ID=int(os.getenv('GUILD_ID','0') or 0)
BASE=Path(os.getenv('BASE_IMAGE','/var/lib/libvirt/images/ubuntu-24.04-server-cloudimg-amd64.img'))
VM_DIR=Path(os.getenv('VM_DIR','/var/lib/libvirt/images/discord-vps'))
BRIDGE=os.getenv('LIBVIRT_BRIDGE','br0')
DB=Path(os.getenv('DB_PATH','/var/lib/discord-kvm-bot/bot.sqlite3'))
MAX_VPS=int(os.getenv('MAX_VPS_PER_USER','1'))
VCPUS=int(os.getenv('DEFAULT_VCPUS','2'))
DEFAULT_DISK=int(os.getenv('DEFAULT_DISK_GB','20'))
if not TOKEN: raise SystemExit('DISCORD_TOKEN is missing. Edit .env first.')
VM_DIR.mkdir(parents=True,exist_ok=True); DB.parent.mkdir(parents=True,exist_ok=True)

def connect():
 c=sqlite3.connect(DB); c.row_factory=sqlite3.Row
 c.execute('CREATE TABLE IF NOT EXISTS vps(name TEXT PRIMARY KEY, owner INTEGER NOT NULL, ram INTEGER NOT NULL, vcpus INTEGER NOT NULL, disk INTEGER NOT NULL)')
 c.execute('CREATE TABLE IF NOT EXISTS limits(uid INTEGER PRIMARY KEY, maxv INTEGER NOT NULL)'); c.commit(); return c

def run(args, timeout=180):
 p=subprocess.run(args,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=timeout)
 if p.returncode: raise RuntimeError((p.stderr or p.stdout or 'command failed')[-1200:])
 return p.stdout.strip()
def admin(i): return i.user.id in ADMIN_IDS
def own(name,uid):
 with connect() as c: r=c.execute('SELECT * FROM vps WHERE name=? AND owner=?',(name,uid)).fetchone()
 if not r: raise ValueError('VPS ID नहीं मिला या यह तुम्हारा VPS नहीं है।')
 return r
def limit(uid):
 with connect() as c: r=c.execute('SELECT maxv FROM limits WHERE uid=?',(uid,)).fetchone()
 return r['maxv'] if r else MAX_VPS
def myvps(uid):
 with connect() as c: return c.execute('SELECT * FROM vps WHERE owner=?',(uid,)).fetchall()
def pwgen(): return ''.join(secrets.choice(string.ascii_letters+string.digits+'!@#%_-') for _ in range(20))
def cloud_init(name,pw):
 hashed=run(['openssl','passwd','-6',pw])
 keypath=os.getenv('SSH_PUBLIC_KEY_PATH','')
 keys=[]
 if keypath and Path(keypath).is_file():
  key=Path(keypath).read_text().strip()
  if key and '\n' not in key: keys=[key]
 key_yaml='    ssh_authorized_keys:\n'+''.join('      - '+k+'\n' for k in keys) if keys else ''
 user=f"""#cloud-config
hostname: {name}
users:
  - default
  - name: vpsuser
    groups: [sudo]
    shell: /bin/bash
    lock_passwd: false
    passwd: '{hashed}'
    sudo: ALL=(ALL) NOPASSWD:ALL
{key_yaml}ssh_pwauth: true
chpasswd:
  expire: false
packages: [qemu-guest-agent]
runcmd:
  - systemctl enable --now qemu-guest-agent
"""
 work=VM_DIR/(name+'-seed'); work.mkdir(mode=0o700,parents=True,exist_ok=True)
 (work/'user-data').write_text(user); (work/'meta-data').write_text(f'instance-id: {name}\nlocal-hostname: {name}\n')
 iso=VM_DIR/(name+'-seed.iso'); run(['cloud-localds',str(iso),str(work/'user-data'),str(work/'meta-data')]); return iso

def create_vm(uid,ramgb,diskgb):
 if not BASE.is_file(): raise RuntimeError(f'Ubuntu cloud image नहीं मिली: {BASE}')
 name=f'vps-{uid}-{secrets.token_hex(3)}'; disk=VM_DIR/(name+'.qcow2'); pw=pwgen(); seed=None
 try:
  run(['qemu-img','create','-f','qcow2','-F','qcow2','-b',str(BASE),str(disk),f'{diskgb}G'])
  seed=cloud_init(name,pw)
  run(['virt-install','--name',name,'--memory',str(ramgb*1024),'--vcpus',str(VCPUS),'--import','--os-variant','ubuntu24.04','--disk',f'path={disk},format=qcow2,bus=virtio','--disk',f'path={seed},device=cdrom','--network',f'bridge={BRIDGE},model=virtio','--graphics','none','--noautoconsole','--channel','unix,target.type=virtio,name=org.qemu.guest_agent.0'],240)
  with connect() as c: c.execute('INSERT INTO vps VALUES(?,?,?,?,?)',(name,uid,ramgb*1024,VCPUS,diskgb))
  return name,pw
 except Exception:
  try: run(['virsh','destroy',name],20)
  except: pass
  try: run(['virsh','undefine',name,'--nvram'],20)
  except: pass
  disk.unlink(missing_ok=True)
  if seed: Path(seed).unlink(missing_ok=True)
  raise

def ip_for(name):
 for source in ('agent','lease'):
  try:
   out=run(['virsh','domifaddr',name,'--source',source],20)
   for line in out.splitlines():
    m=re.search(r'(\d{1,3}(?:\.\d{1,3}){3})/\d+',line)
    if m and not m.group(1).startswith('127.'): return m.group(1)
  except: pass
 return 'अभी उपलब्ध नहीं; 1–2 मिनट बाद /vps info चलाएँ'

intents=discord.Intents.default(); bot=commands.Bot(command_prefix='!',intents=intents)
vps=app_commands.Group(name='vps',description='अपने KVM VPS को manage करें')
admincmd=app_commands.Group(name='admin',description='Admin-only controls')
async def private(i,msg=None,embed=None):
 if i.response.is_done(): await i.followup.send(content=msg,embed=embed,ephemeral=True)
 else: await i.response.send_message(content=msg,embed=embed,ephemeral=True)

@vps.command(name='create',description='Ubuntu KVM VPS बनाएं (default 2 GB RAM)')
@app_commands.choices(ram=[app_commands.Choice(name='1 GB',value=1),app_commands.Choice(name='2 GB',value=2),app_commands.Choice(name='4 GB',value=4)])
@app_commands.describe(ram='RAM चुनें',disk_gb='Disk size: 10–100 GB')
async def create(i:discord.Interaction,ram:app_commands.Choice[int]=None,disk_gb:app_commands.Range[int,10,100]=DEFAULT_DISK):
 await i.response.defer(ephemeral=True,thinking=True)
 if len(myvps(i.user.id))>=limit(i.user.id): return await i.followup.send(f'VPS limit पूरी है ({limit(i.user.id)}). Admin से limit बढ़वाएँ।',ephemeral=True)
 rg=ram.value if ram else 2
 try:
  name,pw=await asyncio.to_thread(create_vm,i.user.id,rg,disk_gb); ip=await asyncio.to_thread(ip_for,name)
  em=discord.Embed(title='KVM VPS Created',color=0x2ecc71)
  for k,v in [('VPS ID',f'`{name}`'),('IP Address',f'`{ip}`'),('SSH User','`vpsuser`'),('SSH Command',f'`ssh vpsuser@{ip}`' if ip.count('.')==3 else 'IP मिलने के बाद SSH करें'),('Password',f'||`{pw}`||'),('Plan',f'{rg} GB RAM · {VCPUS} vCPU · {disk_gb} GB disk')]: em.add_field(name=k,value=v,inline=False)
  try: await i.user.send(embed=em); dm='Details तुम्हारे DM में भेज दी गई हैं.'
  except discord.Forbidden: await i.followup.send(embed=em,ephemeral=True); dm='DM बंद है, details private reply में दिखाई गई हैं.'
  await i.followup.send(f'✅ `{name}` create हो गया. {dm}',ephemeral=True)
 except Exception as e: await i.followup.send(f'Create failed: `{str(e)[:900]}`',ephemeral=True)

@vps.command(name='list',description='अपने VPS देखें')
async def listv(i:discord.Interaction):
 rows=myvps(i.user.id)
 if not rows:return await private(i,'कोई VPS नहीं है. `/vps create` चलाएँ।')
 lines=[]
 for r in rows:
  try:s=await asyncio.to_thread(run,['virsh','domstate',r['name']],20)
  except:s='unknown'
  lines.append(f"`{r['name']}` — {s} — {r['ram']//1024} GB RAM")
 await private(i,'\n'.join(lines))

@vps.command(name='info',description='VPS IP और status देखें')
@app_commands.describe(vps_id='VPS ID')
async def info(i:discord.Interaction,vps_id:str):
 try:
  own(vps_id,i.user.id); ip=await asyncio.to_thread(ip_for,vps_id); state=await asyncio.to_thread(run,['virsh','domstate',vps_id],20)
  await private(i,f'**ID:** `{vps_id}`\n**IP:** `{ip}`\n**Status:** `{state}`\n**SSH:** `ssh vpsuser@{ip}`')
 except Exception as e: await private(i,str(e))

async def act(i,name,action):
 try:
  own(name,i.user.id); await asyncio.to_thread(run,['virsh',action,name],60); await private(i,f'✅ `{name}`: `{action}` command चला दी गई।')
 except Exception as e: await private(i,f'❌ {e}')
def make_action_callback(action):
 async def cb(i: discord.Interaction, vps_id: str):
  await act(i, vps_id, action)
 return cb

for cmdname,action,desc in [('start','start','VPS start करें'),('stop','shutdown','VPS को gracefully stop करें'),('restart','reboot','VPS restart करें'),('force-stop','destroy','VPS को force stop करें')]:
 cmd=app_commands.Command(name=cmdname,description=desc,callback=make_action_callback(action))
 vps.add_command(cmd)

@vps.command(name='ssh',description='SSH connection command दिखाएं')
@app_commands.describe(vps_id='VPS ID')
async def ssh(i:discord.Interaction,vps_id:str):
 try:
  own(vps_id,i.user.id); ip=await asyncio.to_thread(ip_for,vps_id); await private(i,f'**SSH:** `ssh vpsuser@{ip}`\n**Port:** `22`\nPassword create-time DM में भेजा गया था।')
 except Exception as e: await private(i,str(e))

@vps.command(name='delete',description='अपना VPS और disk permanently हटाएं')
@app_commands.describe(vps_id='VPS ID')
async def delete(i:discord.Interaction,vps_id:str):
 try:
  own(vps_id,i.user.id)
  try: await asyncio.to_thread(run,['virsh','destroy',vps_id],30)
  except: pass
  await asyncio.to_thread(run,['virsh','undefine',vps_id,'--nvram'],30)
  (VM_DIR/(vps_id+'.qcow2')).unlink(missing_ok=True); (VM_DIR/(vps_id+'-seed.iso')).unlink(missing_ok=True)
  with connect() as c:c.execute('DELETE FROM vps WHERE name=?',(vps_id,))
  await private(i,f'🗑️ `{vps_id}` हटाया गया।')
 except Exception as e: await private(i,f'Delete failed: {e}')

@vps.command(name='reinstall',description='Ubuntu reinstall: VPS का data मिटेगा')
@app_commands.describe(vps_id='VPS ID')
async def reinstall(i:discord.Interaction,vps_id:str):
 try:
  own(vps_id,i.user.id)
  await private(i,'⚠️ Reinstall VPS का data मिटा देता है। यह starter build में सुरक्षित रूप से confirm होने तक disabled है; admin से manual reinstall करवाएँ।')
 except Exception as e: await private(i,str(e))

@admincmd.command(name='limit',description='किसी user की VPS limit बदलें')
@app_commands.describe(user='Discord user',count='Maximum VPS count')
async def setlimit(i:discord.Interaction,user:discord.User,count:app_commands.Range[int,0,20]):
 if not admin(i):return await private(i,'Admin only.')
 with connect() as c:c.execute('INSERT INTO limits VALUES(?,?) ON CONFLICT(uid) DO UPDATE SET maxv=excluded.maxv',(user.id,count))
 await private(i,f'{user.mention} की VPS limit `{count}` कर दी गई।')

@admincmd.command(name='create',description='किसी user के लिए VPS बनाएं')
@app_commands.describe(user='VPS owner',ram_gb='RAM in GB',disk_gb='Disk size 10–100 GB')
@app_commands.choices(ram_gb=[app_commands.Choice(name='1 GB',value=1),app_commands.Choice(name='2 GB',value=2),app_commands.Choice(name='4 GB',value=4)])
async def admincreate(i:discord.Interaction,user:discord.User,ram_gb:app_commands.Choice[int]=None,disk_gb:app_commands.Range[int,10,100]=DEFAULT_DISK):
 if not admin(i):return await private(i,'Admin only.')
 await i.response.defer(ephemeral=True,thinking=True)
 try:
  name,pw=await asyncio.to_thread(create_vm,user.id,ram_gb.value if ram_gb else 2,disk_gb); ip=await asyncio.to_thread(ip_for,name)
  try: await user.send(f'✅ Admin ने VPS बनाया\nID: `{name}`\nIP: `{ip}`\nSSH: `ssh vpsuser@{ip}`\nPassword: ||`{pw}`||')
  except discord.Forbidden: pass
  await i.followup.send(f'Created `{name}` for {user.mention}.',ephemeral=True)
 except Exception as e: await i.followup.send(f'Create failed: {e}',ephemeral=True)

@admincmd.command(name='panel',description='सभी VPS की सूची')
async def panel(i:discord.Interaction):
 if not admin(i):return await private(i,'Admin only.')
 with connect() as c:rows=c.execute('SELECT * FROM vps LIMIT 30').fetchall()
 await private(i,'\n'.join(f"`{r['name']}` · owner `{r['owner']}` · {r['ram']//1024} GB · {r['disk']} GB" for r in rows) or 'कोई VPS record नहीं।')

@admincmd.command(name='delete',description='Admin द्वारा VPS हटाएं')
@app_commands.describe(vps_id='VPS ID')
async def admindelete(i:discord.Interaction,vps_id:str):
 if not admin(i):return await private(i,'Admin only.')
 try:
  with connect() as c:r=c.execute('SELECT * FROM vps WHERE name=?',(vps_id,)).fetchone()
  if not r:return await private(i,'VPS नहीं मिला।')
  try:await asyncio.to_thread(run,['virsh','destroy',vps_id],30)
  except:pass
  await asyncio.to_thread(run,['virsh','undefine',vps_id,'--nvram'],30)
  (VM_DIR/(vps_id+'.qcow2')).unlink(missing_ok=True); (VM_DIR/(vps_id+'-seed.iso')).unlink(missing_ok=True)
  with connect() as c:c.execute('DELETE FROM vps WHERE name=?',(vps_id,))
  await private(i,f'Deleted `{vps_id}`.')
 except Exception as e:await private(i,f'Delete failed: {e}')

bot.tree.add_command(vps); bot.tree.add_command(admincmd)
@bot.event
async def on_ready():
 try:
  if GUILD_ID:
   g=discord.Object(id=GUILD_ID);bot.tree.copy_global_to(guild=g);s=await bot.tree.sync(guild=g)
  else:s=await bot.tree.sync()
  print(f'Logged in as {bot.user}; synced {len(s)} slash commands')
 except Exception as e:print('Slash sync failed:',e)
bot.run(TOKEN)
