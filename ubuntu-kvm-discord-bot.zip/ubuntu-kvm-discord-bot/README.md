# Ubuntu KVM Discord VPS Bot

Starter Discord slash-command bot for Ubuntu KVM/libvirt guests. Default RAM is 2 GB. Includes create/list/info/ssh/start/stop/restart/force-stop/delete, admin create/limit/panel/delete and DM on creation.

## Important
- Requires an actual KVM-capable Ubuntu host with `libvirt`, `virt-install`, `cloud-localds`, `qemu-img`, `openssl` and an Ubuntu 24.04 cloud image.
- `br0` must already be correctly configured by your hosting provider. This bot does NOT allocate public IPv4 addresses. Public IP routing, bridge setup, provider MAC restrictions and firewall are host/provider responsibilities. If no routed public IP is provided, use NAT/private networking and configure port forwarding instead.
- Reinstall is intentionally disabled in this starter to prevent accidental data loss. Delete permanently erases the guest disk.
- Bot process has powerful host privileges. Test on a disposable host and only allow trusted users. This is a starter, not a production multi-tenant cloud platform.
- Guests get `vpsuser` and a random password DM. Prefer setting `SSH_PUBLIC_KEY_PATH` to a valid SSH public key. Discord DMs can be disabled by the user.

## Discord setup
Create a bot in Discord Developer Portal, copy its token, and invite with `bot` and `applications.commands` scopes. Get your user ID and test server ID with Developer Mode enabled.

## Install on Ubuntu host
Extract this ZIP to `/opt/ubuntu-kvm-discord-bot`, then run:

```bash
sudo apt update
sudo apt install -y qemu-kvm libvirt-daemon-system libvirt-clients virtinst qemu-utils cloud-image-utils openssl python3 python3-venv wget
sudo systemctl enable --now libvirtd
sudo mkdir -p /var/lib/libvirt/images/discord-vps
sudo wget -O /var/lib/libvirt/images/ubuntu-24.04-server-cloudimg-amd64.img https://cloud-images.ubuntu.com/noble/current/noble-server-cloudimg-amd64.img
cd /opt/ubuntu-kvm-discord-bot
python3 -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
nano .env
```

Fill `DISCORD_TOKEN`, `ADMIN_IDS`, and `GUILD_ID`. Change `LIBVIRT_BRIDGE=br0` to your already-configured bridge. Do not invent a bridge name: check `ip link` and ask your provider for public IP bridge/routing instructions. Do not change a remote management NIC's network settings blindly or you may disconnect your host.

## Test run
```bash
cd /opt/ubuntu-kvm-discord-bot
set -a; source .env; set +a
sudo -E .venv/bin/python bot.py
```

If the bot is not run as root, configure precise libvirt permissions and directory access first; do not grant broad sudo access to arbitrary Discord users.

## Run 24/7 with systemd
Create `/etc/systemd/system/discord-kvm-bot.service`:

```ini
[Unit]
Description=Discord KVM VPS Bot
After=network-online.target libvirtd.service
Wants=network-online.target

[Service]
Type=simple
WorkingDirectory=/opt/ubuntu-kvm-discord-bot
EnvironmentFile=/opt/ubuntu-kvm-discord-bot/.env
ExecStart=/opt/ubuntu-kvm-discord-bot/.venv/bin/python /opt/ubuntu-kvm-discord-bot/bot.py
Restart=on-failure
RestartSec=5
User=root
UMask=0077

[Install]
WantedBy=multi-user.target
```

Then:
```bash
sudo systemctl daemon-reload
sudo systemctl enable --now discord-kvm-bot
sudo systemctl status discord-kvm-bot --no-pager
sudo journalctl -u discord-kvm-bot -f
```

## Commands
- `/vps create` — RAM 1/2/4 GB, disk 10–100 GB
- `/vps list`, `/vps info`, `/vps ssh`
- `/vps start`, `/vps stop`, `/vps restart`, `/vps force-stop`, `/vps delete`
- `/vps reinstall` — intentionally disabled in this starter
- `/admin create`, `/admin limit`, `/admin panel`, `/admin delete`
